from setuptools import setup, find_packages

setup(name='swing',
 
      version='0.0.1',
 
      url='https://github.com/Lee-Jiyoung/SWING.py',
 
      license='MIT',
 
      author='Lee Ji young',
 
      author_email='izzzzzi099@gmail.com',
 
      description= 'package malware detection tool',
 
      packages=find_packages()
      )

